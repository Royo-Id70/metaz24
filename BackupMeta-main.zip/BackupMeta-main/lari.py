#Tools Backup By Rayhan
#Sc Buat Jalanin Sc Aja Di Recode LoL

import os

M = '\x1b[1;91m' # MERAH
K = '\x1b[1;93m' # KUNING
H = '\x1b[1;92m' # HIJAU
P = '\x1b[1;97m' # PUTIH
B = '\x1b[1;96m' # BIRU

os.system('git pull')
os.system('clear')
print(f'-----------------------------------------------')
print(f'| {K}Tools Ini Dibuat Oleh Rayhan, Good Job ! {P}   |')
print(f'| Silahkan Baca Dan Pahami Ketentuan Dibawah  |')
print(f'-----------------------------------------------')
print(f'| Ketika Crack Diharuskan Memasukkan Username |')
print(f'| Dan Password, Masukkan Seperti Dibawah!     |')
print(f'-----------------------------------------------\n')
print(f'{P}[{K}?{P}] Enter SC Username ({H}required{P}) : {H}meta')
print(f'{P}[{K}?{P}] Enter SC Password ({H}required{P}) : {H}metaroyid\n')
print(f'{P}--------------------------------------------------')
print(f'{P}| Sc {K}Meta {P}Bukan Buatan Saya Melainkan ({K}Roy ID{P}) ! |')
print(f'| Dan Sc {K}Meta{P} Telah Dihapus Ini Adalah Backupnya |')
print(f'{P}--------------------------------------------------')
print(f'| Sc Mungkin {M}Error {P}Jika Dibuka Dari Direktori |\n| Penyimpanan Atau Tidak Melalui Penginstalan |')
print(f'{P}-----------------------------------------------------')
print(f'| {K}Ingat Dan Jangan Lupakan {H}Username {K}Dan {H}Passwordnya{P} |')
print(f'{P}-----------------------------------------------------')
print(f'{P}| Jika Paham Ketik {H}Lanjut {P}Untuk Melanjutkan |')
print(f'| Ketik {M}Out {P}Untuk Keluar Dari Script        |')
print(f'{P}---------------------------------------------')
pilih = input(f'{K}\nKetik{P}: {H}')
if pilih == 'lanjut' or pilih == 'Lanjut':
      os.system('python .1oJpCk54gQPxq02S.py')
if pilih == 'out' or pilih == 'Out':
      print(f'{B}\nTerimakasih Telah Menggunakan Tools Ini Enjoy>_<\n')
      exit()