<h1 align="center"><b>Sebuah Tools Untuk Menginstall Sc Meta</b></h1>

<div align="center">
  
  <img align="right" alt="GIF" src="https://raw.githubusercontent.com/devSouvik/devSouvik/master/gif3.gif" width="500"/>
  </a>
  <a href="https://github.com/RayhanZuck">
    <img alt="Python ^" src="https://img.shields.io/static/v1?label=Code&message=Python&color=brightgreen"/>
  </a>
  <a href="https://github.com/RayhanZuck">
    <img alt="Update Terakhir" src="https://img.shields.io/badge/Update%20Terakhir-7 Juni-orange"/>
  </a>
   <a href="https://github.com/RayhanZuck">
    <img alt="Ukuran Repo" src="https://img.shields.io/badge/Ukuran%20Repo-5.38MB-blue"/>
  </a>
<a href="https://www.facebook.com/RayhanBusiness">
    <img alt="Starts" src="https://img.shields.io/badge/facebook:%20Rayhan%20Business-344E86?style=for-the-badge&logo=facebook&logoColor=white"/>
  </a>
  <a href="https://www.facebook.com/Rayhan.27.Xyz">
    <img alt="Starts" src="https://img.shields.io/badge/facebook:%20Rayhan%20Cringe%20Ajg-344E86?style=for-the-badge&logo=facebook&logoColor=white"/>
  </a>
  <a href="https://github.com/RayhanZuck">
    <img alt="Forks" src="https://img.shields.io/badge/Github:%20RayhanZuck-lightgrey?style=for-the-badge&logo=github&logoColor=white"/>
  </a>
</div>
<br>

## Tampilan Awal
<img alt="Rayhan" src="https://gambar-upload.rayhan-xyz.repl.co/tampilanawal.jpg"/>

## Tampilan Asli
<img alt="Rayhan" src="https://gambar-upload.rayhan-xyz.repl.co/tampilanasli.jpg"/>

#### Tools Ini Menggunakan Sc Meta Asli Tanpa Recode Sedikit Pun

## Cara Pasang Dan Jalankan
```sh
git clone https://github.com/RayhanZuck/BackupMeta
cd BackupMeta
python lari.py
```
